#ifndef verificarPrimo_H
#define verificarPrimo_H
bool ehPrimo(int n);
int maiorPrimoAnterior(int n);
#endif

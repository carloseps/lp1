#include "fatorial.h"

//Fiz usando os conceitos q aprendi sobre recursividade praticando com Haskell em FMC1
int fatorial(int n){
    if(n == 0) {
        return 1;
    }
    else return (n * fatorial(n - 1));
}

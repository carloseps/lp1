#ifndef FATORIAL_H
#define FATORIAL_H
int fatorial(int n);
#endif

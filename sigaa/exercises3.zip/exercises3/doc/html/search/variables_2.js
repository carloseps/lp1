var searchData=
[
  ['nome_51',['nome',['../classPessoa.html#a3d7ee683889ed031031beba721aa8470',1,'Pessoa::nome()'],['../structAluno.html#a1e24b848527bc6fae76bc28f4fdaaf64',1,'Aluno::nome()'],['../classFuncionario.html#ac9e214af6fa91e21aa376a81e28f17ae',1,'Funcionario::nome()']]],
  ['notas_52',['notas',['../structAluno.html#ad62f99029210b8e97ef23adf59f4668e',1,'Aluno']]]
];

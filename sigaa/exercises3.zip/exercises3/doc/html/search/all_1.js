var searchData=
[
  ['calculamedia_1',['calculaMedia',['../Q2_2main_8cpp.html#a0121b7d0e6aaa290f92e1c4dc7554d7e',1,'calculaMedia(int array[], int tamanho):&#160;main.cpp'],['../Q3_2main_8cpp.html#aae965aa4c724b082d3bd0ad364c5ae43',1,'calculaMedia(double array[], int tamanho):&#160;main.cpp']]],
  ['calculasituacao_2',['calculaSituacao',['../Q3_2main_8cpp.html#a240e74b19949e1387846b3fa52e47814',1,'main.cpp']]],
  ['copia_5fdados_3',['copia_dados',['../Q4_2main_8cpp.html#ae83b55451a5e2e9e0f5a99cb63f822cf',1,'main.cpp']]]
];

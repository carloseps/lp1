var searchData=
[
  ['pessoa_43',['Pessoa',['../classPessoa.html#a22563fe1f53faa9b1d8d10d28ae0c650',1,'Pessoa::Pessoa()'],['../classPessoa.html#aa7ea5fbd78a99d5bf4c665426a2a530a',1,'Pessoa::Pessoa(const std::string &amp;nome)']]]
];

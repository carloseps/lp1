var searchData=
[
  ['getdepto_9',['getDepto',['../classFuncionario.html#a11fc7089f82a2e035bbd05bafc1505c0',1,'Funcionario']]],
  ['getfuncional_10',['getFuncional',['../classFuncionario.html#a37198f7fb5db97d9e24d34c906c00632',1,'Funcionario']]],
  ['getnome_11',['getNome',['../classPessoa.html#a309bd1dada952c5c9b6aa27c163d1e53',1,'Pessoa::getNome()'],['../classFuncionario.html#ae053dda052c468ec8511e2f1e7300a24',1,'Funcionario::getNome()']]],
  ['getsalario_12',['getSalario',['../classFuncionario.html#a220421eb5ff5c97abcf29c19a91bb444',1,'Funcionario']]]
];

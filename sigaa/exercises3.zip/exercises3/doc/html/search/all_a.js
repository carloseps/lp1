var searchData=
[
  ['tamanho_26',['TAMANHO',['../Q1_2main_8cpp.html#a26f0ea282edd059abe2074fb9a0152df',1,'TAMANHO():&#160;main.cpp'],['../Q2_2main_8cpp.html#a26f0ea282edd059abe2074fb9a0152df',1,'TAMANHO():&#160;main.cpp']]]
];
